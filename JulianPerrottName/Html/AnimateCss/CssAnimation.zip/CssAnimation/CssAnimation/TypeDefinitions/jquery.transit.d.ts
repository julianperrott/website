/// <reference path="jquery.d.ts" />

interface JQuery {
    transition(properties?: Object, duration?: any, easing?: any, callback?: Function);

}
